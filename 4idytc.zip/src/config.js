export default {
  API_ENDPOINT: 'process.env.API_URL',
  TOKEN_KEY: 'process.env.TOKEN_KEY'
};
